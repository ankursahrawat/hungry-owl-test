import { getJsonBody, methodNotAllowed } from "../lib/api-utils.js";

export default async function handler(req, res) {
  if (req.method !== "POST") return methodNotAllowed(res, ["POST"]);
  const { pin, role } = getJsonBody(req);
  const expected = role === "staff"
    ? (process.env.STAFF_PIN || process.env.ADMIN_PIN)
    : process.env.ADMIN_PIN;
  if (!expected) {
    const missingVar = role === "staff" ? "STAFF_PIN nor ADMIN_PIN" : "ADMIN_PIN";
    return res.status(500).json({ ok: false, error: `Neither ${missingVar} is set in Vercel env vars.` });
  }
  return res.status(200).json({ ok: pin === expected });
}
