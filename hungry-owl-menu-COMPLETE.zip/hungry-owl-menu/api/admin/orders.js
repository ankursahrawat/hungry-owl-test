import { redis, missingRedisConfig } from "../../lib/redis.js";
import { methodNotAllowed, requireAdmin } from "../../lib/api-utils.js";
import { getAllOrders } from "../../lib/orders-store.js";
import { resolveRange, computeAnalytics } from "../../lib/analytics.js";

const orderKey = (orderNo) => `order:${orderNo}`;

const ALLOWED_STATUSES    = new Set(["NEW", "PREPARING", "READY", "DELIVERED", "CANCELLED"]);
const ALLOWED_TRANSITIONS = {
  NEW:       new Set(["DELIVERED", "CANCELLED"]),
  PREPARING: new Set(["DELIVERED", "CANCELLED"]),
  READY:     new Set(["DELIVERED", "CANCELLED"]),
};
const VALID_RANGES = new Set(["today", "yesterday", "week", "month", "quarter", "year", "custom"]);

export default async function handler(req, res) {
  if (req.method === "GET") return handleGet(req, res);
  if (req.method === "PATCH") return handlePatch(req, res);
  return methodNotAllowed(res, ["GET", "PATCH"]);
}

async function handleGet(req, res) {
  const expected = process.env.ADMIN_PIN;
  if (!expected) return res.status(500).json({ error: "ADMIN_PIN is not set in Vercel env vars." });
  if (req.query.pin !== expected) return res.status(401).json({ error: "Wrong PIN" });
  if (missingRedisConfig()) return res.status(500).json({ error: "Database not configured." });

  res.setHeader("Cache-Control", "no-store");

  if (req.query.range) {
    const range = req.query.range;
    if (!VALID_RANGES.has(range)) return res.status(400).json({ error: `Invalid range "${range}"` });
    let resolved;
    try {
      resolved = resolveRange(range, req.query.from, req.query.to);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    const orders = await getAllOrders();
    const result = computeAnalytics(orders, resolved);
    return res.status(200).json({ range, from: resolved.fromMs, to: resolved.toMs, groupBy: resolved.groupBy, ...result });
  }

  if (req.query.orderNo) {
    const raw = await redis.get(orderKey(req.query.orderNo));
    if (!raw) return res.status(404).json({ error: "Order not found" });
    const order = typeof raw === "string" ? JSON.parse(raw) : raw;
    return res.status(200).json({ order });
  }

  const orders = await getAllOrders();
  return res.status(200).json({ orders });
}

async function handlePatch(req, res) {
  const body = requireAdmin(req, res);
  if (!body) return;
  if (missingRedisConfig()) return res.status(500).json({ error: "Database not configured." });

  const { orderNo, status, isDummy } = body;
  if (!orderNo) return res.status(400).json({ error: "Missing orderNo" });
  if (status === undefined && isDummy === undefined) {
    return res.status(400).json({ error: "Nothing to update — provide status and/or isDummy" });
  }

  const raw = await redis.get(orderKey(orderNo));
  if (!raw) return res.status(404).json({ error: "Order not found" });
  const order = typeof raw === "string" ? JSON.parse(raw) : raw;

  if (status !== undefined) {
    if (!ALLOWED_STATUSES.has(status)) return res.status(400).json({ error: `Invalid status "${status}"` });
    const allowedNext = ALLOWED_TRANSITIONS[order.status];
    if (!allowedNext || !allowedNext.has(status)) {
      return res.status(400).json({ error: `Cannot change status from ${order.status} to ${status}` });
    }
    order.status = status;
  }
  if (isDummy !== undefined) order.isDummy = !!isDummy;

  order.updatedAt = Date.now();
  await redis.set(orderKey(orderNo), JSON.stringify(order));
  return res.status(200).json({ ok: true, order });
}
